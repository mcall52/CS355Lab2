package cs355.view;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.Observable;

import Transform.Transform;
import cs355.GUIFunctions;
import cs355.model.drawing.DrawingModel;
import cs355.model.drawing.Shape;
import drawing.DrawableShape;
import drawing.DrawableShapeFactory;

public class View implements ViewRefresher {

	private DrawableShapeFactory factory = new DrawableShapeFactory();
	private DrawingModel model;
	
	private double scalefactor;
	private Point2D.Double viewupperleft;
	
	public View(){
		scalefactor = 1.0;
		//doZoom();
	}

	
	@Override
	public void update(Observable arg0, Object arg1) {
		// TODO Auto-generated method stub
		GUIFunctions.refresh();
	}

	@Override
	public void refreshView(Graphics2D g2d) {
		
		for(Shape s: model.getShapes()){
			DrawableShape shape = factory.createShape(s);
			//create and set world to view transform
			AffineTransform worldToView = 
					Transform.worldToView(viewupperleft.x, viewupperleft.y, scalefactor);
			factory.setWorldToView(worldToView);
			shape.draw(g2d);
		}
		DrawableShape selectedShape = factory.createShape(model.getSelectedShape());
		if(selectedShape != null) {
			selectedShape.drawOutline(g2d);
		}
	}

	public void addModel(DrawingModel model) {
		this.model = model;
		model.addObserver(this);
		
	}

	public double getScaleFactor(){
		return scalefactor;
	}
	
	public void zoomIn(){
		scalefactor *= 2;
	//doZoom();
	}
	
	public void zoomOut(){
		scalefactor /= 2;
		//doZoom();
	}
	
	public void doZoom(){
		int vbarsize = (int) (512 / scalefactor);
		int hbarsize = (int) (512 / scalefactor);

		GUIFunctions.setZoomText(scalefactor);
		
		GUIFunctions.setHScrollBarKnob(hbarsize);
		GUIFunctions.setHScrollBarPosit(1024 - (hbarsize / 2));
		
		GUIFunctions.setVScrollBarKnob(vbarsize);
		GUIFunctions.setHScrollBarPosit(1024 - (vbarsize / 2));
	}
	
	public void setViewUpperLeft(Point2D.Double vul){
		viewupperleft = vul;
	}
	
}
