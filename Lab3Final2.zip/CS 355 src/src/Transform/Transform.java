package Transform;

import java.awt.geom.AffineTransform;

public class Transform {
//	public static AffineTransform translate(double x, double y){
//		AffineTransform translate = new AffineTransform(1, 0, 0, 1, x, y);
//		return translate;
//	}
//	
//	public static AffineTransform rotate(){
//		return new AffineTransform();		
//	}
	
	public static AffineTransform objToWorld(double centerx, double centery, double rotation){
//		AffineTransform objToWorld = new AffineTransform();
		AffineTransform translate = new AffineTransform(1, 0, 0, 1, centerx, centery);
		AffineTransform rotate = new AffineTransform(Math.cos(rotation), Math.sin(rotation), 
				-Math.sin(rotation), Math.cos(rotation), 0, 0);
		//objToWorld.translate(centerx, centery);
		translate.concatenate(rotate);
//		objToWorld =  translate;
		//objToWorld.rotate(rotation);
		
		return translate;
	}
	
	public static AffineTransform worldToObj(double centerx, double centery, double rotation){
//		AffineTransform objToWorld = new AffineTransform();
		AffineTransform translate = new AffineTransform(1, 0, 0, 1, -centerx, -centery);
		AffineTransform rotate = new AffineTransform(Math.cos(rotation), -Math.sin(rotation),
				Math.sin(rotation), Math.cos(rotation), 0, 0);
//		objToWorld.rotate(-rotation);
//		objToWorld.translate(-centerx, -centery);
		rotate.concatenate(translate);
		return rotate;
	}
	
	public static AffineTransform worldToView(double viewupperleftx, double viewupperlefty, double scalefactor){
		AffineTransform translate = new AffineTransform(1, 0, 0, 1, -viewupperleftx, -viewupperlefty);
		AffineTransform scale = new AffineTransform(scalefactor, 0, 0, scalefactor, 0, 0);
		scale.concatenate(translate);

		return scale;
	}
	
	public static AffineTransform viewToWorld(double viewupperleftx, double viewupperlefty, double scalefactor){
		AffineTransform translate = new AffineTransform(1, 0, 0, 1, viewupperleftx, viewupperlefty);
		AffineTransform scale = new AffineTransform(1/scalefactor, 0, 0, 1/scalefactor, 0, 0);
		translate.concatenate(scale);
		
		return translate;
	}
}
